
echo Chạy chương trình...
python main_gemlogin.py

echo Hoàn tất!
pause